def divide(a, b):
    return a / b  # No zero-check, should raise an error

def is_even(n):
    if n % 2 == 0:
        return True
    else:
        return False  # Can be simplified
